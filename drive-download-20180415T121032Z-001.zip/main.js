function nextpage() {
  window.open("resume.html","_self");
}
function nextpage1() {
    window.open("script.html","_self");
}
